IVESTER'S JUNK REMOVAL WEBSITE

Files:
- index.html: complete responsive website in one file.

Preview:
Open index.html in a web browser.

Publish free with GitHub Pages:
1. Create/sign into a GitHub account at https://github.com/
2. Create a new public repository, for example: ivesters-junk-removal
3. Upload index.html to the repository's main/root folder.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish. The Pages screen will show the website URL.

Notes:
- The quote form prepares a text message to 706-391-0129. It does not send automatically; the customer must tap Send in their messaging app.
- Review all services and the service-area list before publishing. Nearby communities are examples; coverage depends on job location.
- Replace sample text or add real business photos before launch if desired.
- A custom domain name is optional and usually costs extra each year.
